# Harris County Alcohol / DWI-Related Traffic Crash Atlas (2022–2025)

## How to publish
Upload the **contents** of this folder (`index.html`, `crashes.json`, `README.md`) to a static website host. For Netlify Drop, drag the extracted folder to https://app.netlify.com/drop . For GitHub Pages, upload `index.html` and `crashes.json` to the repository root, then enable Pages. The map needs an internet connection to load Leaflet and the basemap. Opening `index.html` directly as a local file may block `fetch('crashes.json')`; use the published site or a local HTTP server.

## Data
Source: user-provided TxDOT CRIS public CSV extract, processed 2026-11-12. County=Harris, years 2022–2025, with TxDOT-authored query filters 'Alcohol Involved Crashes' and 'Driving While Intoxicated'. The map shows all 5,848 unique crash IDs in that export, including non-injury crashes. It is **not** an exhaustive list of all crashes involving drugs or impairment, and no conclusion about confirmed intoxication should be inferred for each individual record. Crashes with missing/invalid coordinates count in statistics but cannot be plotted. Crash severity is based on death count and suspected serious injury count, not confirmed hospitalization.

## Initial task and revisions for extra credit
Initial task: Create a Harris County web map using TxDOT CRIS crash records from 2022–2025, including geocoded crash locations, dates, death and injury counts, a zoomable street basemap, legend and scale bar, and interactive markers. Study area: Harris County, Texas, including local roads.

Revision: Include **all crashes** returned by the alcohol/DWI query, rather than only fatal and serious-injury records. Use light/medium/dark red for fatal crashes with 1–2/3–4/5+ deaths, small yellow dots for nonfatal suspected serious-injury crashes, and small gray-blue dots for other crashes. Add year/month, time-of-day and severity filters, fatal-crash trend chart, density heatmap, and CSV export. Preserve blue water, green parkland, gray urban land and darker roads through the basemap.

## Interpretation
The map communicates geographic patterns and annual changes in reported alcohol/DWI-filtered crashes. Counts are not exposure-adjusted: a corridor with more crashes is not necessarily more dangerous per vehicle-mile. Coordinates may be approximate, and the source extract is subject to updates.
